# 高驰运动健康数据中枢 (CorosHealthApp)

本 Android 应用基于高驰官方 **Model Context Protocol (COROS Official MCP)** 接口打造，专为跑步、骑行及耐力运动爱好者设计。

## 🌟 核心功能
1. **日期与时间区间查询**：支持任选单日、近7天或自定义时间范围拉取数据。
2. **超详尽运动分段与心率指标**：
   - 每公里分段配速（Split Pace，精确至分秒）。
   - 分段平均心率与最高心率（Lap HR / Max HR）。
   - 分段步频（Cadence）与爬升起伏。
3. **日常健康全景汇总**：
   - 晨间静息心率（RHR）。
   - HRV（心率变异性）睡眠恢复评估。
   - 睡眠总时长与日均压力指数。
4. **表格展示与 CSV 导出**：
   - App 内提供清晰直观的分段表格与卡片视图。
   - 支持一键导出标准 UTF-8 BOM CSV 文件，可直接分享至微信、邮箱或用 Excel / WPS 打开查看。
5. **高驰官方授权连接 (OAuth 2.0)**：
   - 支持拉起高驰官方网页完成 OAuth 2.0 登录授权。
   - 提供直接输入 Access Token 的极速模式（填入 `TEST_TOKEN` 可无网络免登录体验完整高精度仿真数据）。

## 🚀 如何打包成 APK？
详细打包教程参见随附文档，支持：
1. **GitHub Actions 极速免环境云端自动打包**（推荐，无需本地安装 Android Studio）。
2. **Android Studio 本地一键打包**。
