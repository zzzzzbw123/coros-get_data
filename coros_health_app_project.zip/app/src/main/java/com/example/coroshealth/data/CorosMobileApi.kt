package com.example.coroshealth.data

import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 高驰手机端私有 API —— 唯一能拿到【睡眠分期/睡眠评分/睡眠心率】的通道。
 * 加密方案逆向自高驰 APK (libencrypt-lib.so)：
 *    XOR(appKey循环) → PKCS7填充 → AES-128-CBC(key=appKey, IV固定) → Base64
 */
object CorosMobileApi {

    private const val TAG = "CorosMobileApi"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private const val PREF_MOBILE_TOKEN = "coros_mobile_token"
    private const val PREF_MOBILE_PAYLOAD = "coros_mobile_payload"
    private const val AES_IV = "weloop3_2015_03#"

    // 抓包自真实手机登录的设备指纹。若未来高驰收紧校验、登录报"Parameter input error"，
    // 需用新版APK重新抓包替换这段。
    private const val YFHEADER = "{\"appVersion\":1125917087236096,\"clientType\":1,\"language\":\"en-US\",\"mobileName\":\"sdk_gphone64_arm64,google,Google\",\"releaseType\":1,\"systemVersion\":\"13\",\"timezone\":4,\"versionCode\":\"404080400\"}"

    private fun mobileHost(isChina: Boolean) =
        if (isChina) "https://apicn.coros.com" else "https://apieu.coros.com"

    data class SleepInfo(
        val total: Int, val deep: Int, val light: Int, val rem: Int,
        val awake: Int, val score: Int, val minHr: Int, val avgHr: Int
    )

    private fun encrypt(plain: String, appKey: String): String {
        val key = appKey.toByteArray(Charsets.US_ASCII)
        val data = plain.toByteArray(Charsets.UTF_8)
        val xored = ByteArray(data.size) { i -> (data[i].toInt() xor key[i % key.size].toInt()).toByte() }
        val pad = 16 - (xored.size % 16)
        val padded = xored + ByteArray(pad) { pad.toByte() }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"),
            IvParameterSpec(AES_IV.toByteArray(Charsets.US_ASCII)))
        return Base64.encodeToString(cipher.doFinal(padded), Base64.NO_WRAP)
    }

    private fun randomAppKey(): String {
        val sr = SecureRandom()
        val sb = StringBuilder(16)
        sb.append(sr.nextInt(9) + 1)
        repeat(15) { sb.append(sr.nextInt(10)) }
        return sb.toString()
    }

    /** 手机端登录：返回 token，并把可重放报文存入 prefs（高驰服务端无防重放，可免密刷新） */
    private fun login(account: String, md5Pwd: String, isChina: Boolean, prefs: SharedPreferences): String? {
        return try {
            val appKey = randomAppKey()
            val payload = JsonObject().apply {
                addProperty("account", encrypt(account, appKey) + "\n")
                addProperty("accountType", 2)
                addProperty("appKey", appKey)
                addProperty("clientType", 1)
                addProperty("hasHrCalibrated", 0)
                addProperty("kbValidity", 0)
                addProperty("pwd", encrypt(md5Pwd, appKey) + "\n")
                addProperty("region", "310|Europe/Berlin|US") // 抓包原值，与账号区服无关
                addProperty("skipValidation", false)
            }
            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val req = Request.Builder()
                .url(mobileHost(isChina) + "/coros/user/login")
                .header("content-type", "application/json")
                .header("user-agent", "okhttp/4.12.0")
                .header("request-time", System.currentTimeMillis().toString())
                .header("yfheader", YFHEADER)
                .post(body)
                .build()
            client.newCall(req).execute().use { resp ->
                val root = gson.fromJson(resp.body?.string(), JsonObject::class.java)
                if (root?.get("result")?.asString != "0000") {
                    Log.w(TAG, "mobile login fail: $root")
                    return null
                }
                val token = root.getAsJsonObject("data")?.get("accessToken")?.asString ?: return null
                prefs.edit().putString(PREF_MOBILE_TOKEN, token)
                    .putString(PREF_MOBILE_PAYLOAD, payload.toString()).apply()
                token
            }
        } catch (e: Exception) {
            Log.w(TAG, "mobile login error: ${e.message}")
            null
        }
    }

    /** 重放保存的登录报文刷新 token */
    private fun refreshByReplay(isChina: Boolean, prefs: SharedPreferences): String? {
        val saved = prefs.getString(PREF_MOBILE_PAYLOAD, null) ?: return null
        return try {
            val body = saved.toRequestBody("application/json; charset=utf-8".toMediaType())
            val req = Request.Builder()
                .url(mobileHost(isChina) + "/coros/user/login")
                .header("content-type", "application/json")
                .header("user-agent", "okhttp/4.12.0")
                .header("request-time", System.currentTimeMillis().toString())
                .header("yfheader", YFHEADER)
                .post(body)
                .build()
            client.newCall(req).execute().use { resp ->
                val root = gson.fromJson(resp.body?.string(), JsonObject::class.java)
                val token = if (root?.get("result")?.asString == "0000")
                    root.getAsJsonObject("data")?.get("accessToken")?.asString else null
                if (token != null) prefs.edit().putString(PREF_MOBILE_TOKEN, token).apply()
                token
            }
        } catch (e: Exception) { null }
    }

    private fun ensureToken(account: String, md5Pwd: String, isChina: Boolean, prefs: SharedPreferences): String? {
        prefs.getString(PREF_MOBILE_TOKEN, null)?.let { return it }
        refreshByReplay(isChina, prefs)?.let { return it }
        return login(account, md5Pwd, isChina, prefs)
    }

    /** 拉取日期范围(YYYYMMDD)的睡眠数据，返回 happenDay -> SleepInfo */
    fun fetchSleepRange(
        startDay: String, endDay: String,
        account: String, md5Pwd: String, isChina: Boolean,
        prefs: SharedPreferences
    ): Map<String, SleepInfo> {
        var token = ensureToken(account, md5Pwd, isChina, prefs) ?: return emptyMap()

        fun doRequest(tk: String): JsonObject? = try {
            val payload = JsonObject().apply {
                addProperty("allDeviceSleep", 1)
                add("dataType", gson.toJsonTree(listOf(5)))
                addProperty("dataVersion", 0)
                addProperty("startTime", startDay.toLong())
                addProperty("endTime", endDay.toLong())
                addProperty("statisticType", 1)
            }
            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val req = Request.Builder()
                .url(mobileHost(isChina) + "/coros/data/statistic/daily?accessToken=$tk")
                .header("Content-Type", "application/json")
                .header("accesstoken", tk)
                .post(body)
                .build()
            client.newCall(req).execute().use { resp ->
                gson.fromJson(resp.body?.string(), JsonObject::class.java)
            }
        } catch (e: Exception) { null }

        var root = doRequest(token)
        // token 失效(1019) → 重放刷新后重试一次
        if (root?.get("result")?.asString == "1019") {
            token = refreshByReplay(isChina, prefs)
                ?: login(account, md5Pwd, isChina, prefs)
                ?: return emptyMap()
            root = doRequest(token)
        }
        if (root?.get("result")?.asString != "0000") {
            Log.w(TAG, "sleep fetch fail: $root")
            return emptyMap()
        }

        val result = mutableMapOf<String, SleepInfo>()
        val dayList = root.getAsJsonObject("data")
            ?.getAsJsonObject("statisticData")
            ?.getAsJsonArray("dayDataList") ?: return emptyMap()

        for (el in dayList) {
            val item = el.asJsonObject
            val day = item.get("happenDay")?.asString ?: continue
            val sd = item.getAsJsonObject("sleepData") ?: continue
            result[day] = SleepInfo(
                total = sd.get("totalSleepTime")?.asInt ?: -1,
                deep = sd.get("deepTime")?.asInt ?: -1,
                light = sd.get("lightTime")?.asInt ?: -1,
                rem = sd.get("eyeTime")?.asInt ?: -1,
                awake = sd.get("wakeTime")?.asInt ?: -1,
                score = item.get("performance")?.asInt ?: -1,
                minHr = sd.get("minHeartRate")?.asInt ?: -1,
                avgHr = sd.get("avgHeartRate")?.asInt ?: -1
            )
        }
        return result
    }
}
