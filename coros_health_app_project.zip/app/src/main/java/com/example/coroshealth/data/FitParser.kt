package com.example.coroshealth.data

import com.example.coroshealth.data.model.TrackPoint
import com.garmin.fit.Decode
import com.garmin.fit.MesgBroadcaster
import com.garmin.fit.RecordMesg
import com.garmin.fit.RecordMesgListener
import java.io.ByteArrayInputStream

object FitParser {

    /**
     * 解析 FIT 二进制字节流为秒级轨迹点列表
     * 提取：Unix时间戳、心率、速度(米/秒)、步频/踏频(spm)、海拔高度(米)、累计距离(米)
     */
    fun parse(bytes: ByteArray): List<TrackPoint> {
        val points = mutableListOf<TrackPoint>()
        if (bytes.isEmpty()) return points

        try {
            val decode = Decode()
            val broadcaster = MesgBroadcaster(decode)

            // 使用 Garmin FIT SDK 提供的官方类型化监听器 RecordMesgListener
            broadcaster.addListener(RecordMesgListener { r: RecordMesg ->
                try {
                    val ts = r.timestamp?.timestamp ?: 0L
                    val hr = r.heartRate?.toInt() ?: -1
                    val speed = r.speed?.toDouble() ?: 0.0
                    val cadence = r.cadence?.toInt() ?: -1
                    val altitude = r.altitude?.toDouble() ?: 0.0
                    val distance = r.distance?.toDouble() ?: 0.0

                    points.add(
                        TrackPoint(
                            timestampSec = ts + 631065600L, // FIT纪元 (1989-12-31 00:00:00 UTC) 偏移至 Unix 纪元
                            heartRate = if (hr in 30..250) hr else -1,
                            speedMps = if (speed in 0.0..100.0) speed else 0.0,
                            cadence = if (cadence in 30..350) cadence else -1,
                            altitude = altitude,
                            distanceM = distance
                        )
                    )
                } catch (_: Exception) {
                    // 单条记录解析容错
                }
            })

            decode.read(ByteArrayInputStream(bytes), broadcaster)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return points
    }
}
