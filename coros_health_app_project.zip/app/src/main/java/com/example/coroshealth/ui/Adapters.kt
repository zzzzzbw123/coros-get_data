package com.example.coroshealth.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coroshealth.data.model.DailyHealthRecord
import com.example.coroshealth.data.model.LapDetail
import com.example.coroshealth.databinding.ItemHealthRowBinding
import com.example.coroshealth.databinding.ItemLapRowBinding

class HealthTableAdapter(private val items: List<DailyHealthRecord>) :
    RecyclerView.Adapter<HealthTableAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemHealthRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHealthRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvDate.text = item.date
        val rhrText = if (item.restingHeartRate >= 0) "${item.restingHeartRate} bpm" else "—"
        val testRhrExtra = if (item.testRhr >= 0) " (测${item.testRhr})" else ""
        holder.binding.tvRestingHr.text = "$rhrText$testRhrExtra"

        val sleepText = when {
            item.sleepDurationMinutes >= 0 && item.sleepScore >= 0 -> "${item.sleepDurationMinutes / 60}h ${item.sleepDurationMinutes % 60}m (${item.sleepScore}分)"
            item.sleepDurationMinutes >= 0 -> "${item.sleepDurationMinutes / 60}h ${item.sleepDurationMinutes % 60}m"
            else -> "—"
        }
        holder.binding.tvSleep.text = sleepText
        holder.binding.tvHrv.text = if (item.hrvValue >= 0) "${item.hrvValue} ms" else "—"
        holder.binding.tvStress.text = if (item.stressAvg >= 0) "${item.stressAvg}" else "—"
        holder.binding.tvSteps.text = if (item.steps >= 0) "${item.steps}" else "—"
        holder.binding.tvLoad.text = if (item.trainingLoad >= 0) "${item.trainingLoad}" else "—"
    }

    override fun getItemCount(): Int = items.size
}

class LapDetailAdapter(private val items: List<LapDetail>) :
    RecyclerView.Adapter<LapDetailAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemLapRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLapRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvLapNum.text = "第 ${item.lapIndex} 段"
        holder.binding.tvPace.text = item.paceFormatted
        holder.binding.tvLapHr.text = if (item.avgHeartRate > 0) "${item.avgHeartRate} bpm" else "—"
        holder.binding.tvMaxHr.text = if (item.maxHeartRate > 0) "${item.maxHeartRate} bpm" else "—"
        holder.binding.tvCadence.text = if (item.cadenceSprm > 0) "${item.cadenceSprm} spm" else "—"
        holder.binding.tvElev.text = "${item.elevationGainMeters} m"
    }

    override fun getItemCount(): Int = items.size
}
