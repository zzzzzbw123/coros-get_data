package com.example.coroshealth.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coroshealth.data.model.DailyHealthRecord
import com.example.coroshealth.data.model.LapDetail
import com.example.coroshealth.databinding.ItemHealthRowBinding
import com.example.coroshealth.databinding.ItemLapRowBinding

class HealthTableAdapter(private val items: List<DailyHealthRecord>) :
    RecyclerView.Adapter<HealthTableAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemHealthRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHealthRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvDate.text = item.date
        holder.binding.tvRestingHr.text = "${item.restingHeartRate} bpm"
        holder.binding.tvSleep.text = "${item.sleepDurationMinutes / 60}h ${item.sleepDurationMinutes % 60}m"
        holder.binding.tvHrv.text = "${item.hrvValue} ms"
        holder.binding.tvStress.text = "${item.stressAvg}"
        holder.binding.tvSteps.text = "${item.steps}"
        holder.binding.tvLoad.text = "${item.trainingLoad}"
    }

    override fun getItemCount(): Int = items.size
}

class LapDetailAdapter(private val items: List<LapDetail>) :
    RecyclerView.Adapter<LapDetailAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemLapRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLapRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvLapNum.text = "第 ${item.lapIndex} km"
        holder.binding.tvPace.text = item.paceFormatted
        holder.binding.tvLapHr.text = "${item.avgHeartRate} bpm"
        holder.binding.tvMaxHr.text = "${item.maxHeartRate} bpm"
        holder.binding.tvCadence.text = "${item.cadenceSprm} spm"
        holder.binding.tvElev.text = "${item.elevationGainMeters} m"
    }

    override fun getItemCount(): Int = items.size
}
