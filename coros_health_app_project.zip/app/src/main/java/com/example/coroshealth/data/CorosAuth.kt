package com.example.coroshealth.data

import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * 高驰 Training Hub 登录工具：
 * 登录成功返回 Triple(token, 实测可用的节点 baseUrl, userId)，失败返回 null。
 * 供 LoginActivity（首次登录）与 MainActivity（Token 过期后自动重登）共同使用。
 */
object CorosAuth {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    /** 明文密码登录 */
    suspend fun login(account: String, password: String, isChina: Boolean): Triple<String, String, String>? {
        return loginWithMd5(account, md5(password), isChina)
    }

    /** 已 MD5 密码登录（用于本地凭据静默重登） */
    suspend fun loginWithMd5(account: String, md5Pwd: String, isChina: Boolean): Triple<String, String, String>? {
        return withContext(Dispatchers.IO) {
            val preferred = if (isChina) "https://teamcnapi.coros.com" else "https://teamapi.coros.com"
            val alternate = if (isChina) "https://teamapi.coros.com" else "https://teamcnapi.coros.com"

            for (baseUrl in listOf(preferred, alternate)) {
                try {
                    val json = JsonObject().apply {
                        addProperty("account", account)
                        addProperty("pwd", md5Pwd)
                        addProperty("accountType", 2)
                    }
                    val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                    val req = Request.Builder()
                        .url("$baseUrl/account/login")
                        .header("Content-Type", "application/json")
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .post(body)
                        .build()

                    var token: String? = null
                    var userId: String? = null
                    client.newCall(req).execute().use { resp ->
                        val str = resp.body?.string() ?: ""
                        val root = try { gson.fromJson(str, JsonObject::class.java) } catch (e: Exception) { null }
                        if (root != null && root.has("data") && root.get("data").isJsonObject) {
                            val d = root.getAsJsonObject("data")
                            for (k in listOf("accessToken", "accesstoken", "token")) {
                                if (d.has(k) && !d.get(k).isJsonNull) { token = d.get(k).asString; break }
                            }
                            for (k in listOf("userId", "userid", "user_id")) {
                                if (d.has(k) && !d.get(k).isJsonNull) { userId = d.get(k).asString; break }
                            }
                        }
                        // 正则兜底
                        if (token.isNullOrBlank()) {
                            val m = Regex("""(?i)"(?:accessToken|accesstoken|token)"\s*:\s*"([a-zA-Z0-9_-]{16,64})"""").find(str)
                            if (m != null) token = m.groupValues[1]
                        }
                        if (userId.isNullOrBlank()) {
                            val m = Regex("""(?i)"(?:userId|userid|user_id)"\s*:\s*"([a-zA-Z0-9_-]+)"""").find(str)
                            if (m != null) userId = m.groupValues[1]
                        }
                        // Cookie / Header 兜底
                        if (token.isNullOrBlank()) {
                            token = resp.header("accesstoken")
                            if (token.isNullOrBlank()) {
                                for (c in resp.headers("Set-Cookie")) {
                                    if (c.contains("CPL-coros-token=")) {
                                        token = c.substringAfter("CPL-coros-token=").substringBefore(";").trim()
                                        break
                                    }
                                }
                            }
                        }
                    }

                    // 拿到 token 后必须在现场带齐三要素实测数据接口，通过才采用
                    if (!token.isNullOrBlank()) {
                        val t = token!!
                        val u = userId ?: ""
                        if (testToken(baseUrl, t, u)) return@withContext Triple(t, baseUrl, u)
                        val otherUrl = if (baseUrl == preferred) alternate else preferred
                        if (testToken(otherUrl, t, u)) return@withContext Triple(t, otherUrl, u)
                    }
                } catch (e: Exception) {
                    // 换下一个节点重试
                }
            }
            null
        }
    }

    private fun testToken(baseUrl: String, token: String, userId: String?): Boolean {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/activity/query?size=5&pageNumber=1&modeList=")
                .header("accesstoken", token)
                .header("Cookie", "gray=th-v2; CPL-coros-token=$token")
                .header("yfheader", "{\"userId\":\"${userId ?: ""}\"}")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                val root = gson.fromJson(body, JsonObject::class.java)
                val code = root?.get("code")?.asString ?: root?.get("result")?.asString ?: root?.get("apiCode")?.asString
                code == "0000"
            }
        } catch (e: Exception) {
            false
        }
    }
}
