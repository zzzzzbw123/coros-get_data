package com.example.coroshealth.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.coroshealth.R
import com.example.coroshealth.databinding.ActivityLoginBinding
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    companion object {
        const val PREFS_NAME = "coros_auth"
        const val KEY_ACCESS_TOKEN = "access_token"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val savedToken = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACCESS_TOKEN, "")
        if (!savedToken.isNullOrBlank()) {
            binding.etManualToken.setText(savedToken)
        }

        // 方式 1：直接输入账号密码，App 自动完成 MD5 哈希并换取官方 Token
        binding.btnDirectLogin.setOnClickListener {
            val account = binding.etAccount.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val isChina = binding.rbChina.isChecked

            if (account.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "请输入高驰登录账号和密码", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performDirectCorosLogin(account, password, isChina)
        }

        // 方式 2：手动粘贴 Token（内置强力智能格式清洗）
        binding.btnSaveManualToken.setOnClickListener {
            val rawToken = binding.etManualToken.text.toString()
            val cleanToken = sanitizeToken(rawToken)

            if (cleanToken.isEmpty()) {
                Toast.makeText(this, "请输入有效的 Access Token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            saveTokenAndFinish(cleanToken, "Token 已清洗并保存成功！")
        }
    }

    private fun performDirectCorosLogin(account: String, pass: String, isChina: Boolean) {
        binding.btnDirectLogin.isEnabled = false
        binding.loginProgress.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val baseUrl = if (isChina) "https://teamcnapi.coros.com" else "https://teamapi.coros.com"
                    val loginUrl = "$baseUrl/account/login"

                    // 高驰官方接口要求密码使用小写 MD5 格式传输
                    val md5Pwd = md5(pass)
                    val jsonBody = JsonObject().apply {
                        addProperty("account", account)
                        addProperty("pwd", md5Pwd)
                        addProperty("accountType", 2) // 2 表示普通账号密码登录
                    }

                    val body = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                    val req = Request.Builder()
                        .url(loginUrl)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .post(body)
                        .build()

                    client.newCall(req).execute().use { resp ->
                        val bodyStr = resp.body?.string() ?: return@withContext Pair(false, "服务器无响应")
                        val root = gson.fromJson(bodyStr, JsonObject::class.java) ?: return@withContext Pair(false, "数据解析异常")

                        val code = root.get("code")?.asString ?: root.get("apiCode")?.asString
                        if (code == "0000" && root.has("data")) {
                            val data = root.getAsJsonObject("data")
                            val token = data.get("accessToken")?.asString
                            if (!token.isNullOrBlank()) {
                                return@withContext Pair(true, token)
                            }
                        }

                        val msg = root.get("message")?.asString ?: root.get("msg")?.asString ?: "登录失败 (错误代码: $code)"
                        Pair(false, msg)
                    }
                } catch (e: Exception) {
                    Pair(false, "网络连接失败: ${e.message}")
                }
            }

            binding.btnDirectLogin.isEnabled = true
            binding.loginProgress.visibility = View.GONE

            if (result.first) {
                saveTokenAndFinish(result.second, "🎉 高驰账号登录成功，已自动绑定！")
            } else {
                Toast.makeText(this@LoginActivity, result.second, Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * 智能清洗用户复制粘贴的 Token，自动剔除前缀、引号、Cookie参数等杂质
     */
    private fun sanitizeToken(raw: String): String {
        var t = raw.trim()
        if (t.equals("TEST_TOKEN", ignoreCase = true)) return "TEST_TOKEN"

        // 提取 Cookie 中的 CPL-coros-token=xxx
        if (t.contains("CPL-coros-token=")) {
            t = t.substringAfter("CPL-coros-token=").substringBefore(";").trim()
        }

        // 剔除可能带上的键名前缀
        t = t.replace(Regex("^(?i)(accesstoken|access_token|token|authorization|bearer)[\\s:=]+"), "")

        // 剔除包裹的引号或分号
        t = t.trim('"', '\'', '`', ' ', '\n', '\r', '\t', ';')

        return t
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun saveTokenAndFinish(token: String, msg: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACCESS_TOKEN, token)
            .apply()

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        finish()
    }
}
