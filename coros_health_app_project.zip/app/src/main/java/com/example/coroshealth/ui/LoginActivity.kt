package com.example.coroshealth.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.coroshealth.databinding.ActivityLoginBinding
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    companion object {
        const val PREFS_NAME = "coros_auth"
        const val KEY_ACCESS_TOKEN = "access_token"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val savedToken = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACCESS_TOKEN, "")
        if (!savedToken.isNullOrBlank()) {
            binding.etManualToken.setText(savedToken)
        }

        // 方式 1：直接输入账号密码，App 自动完成 MD5 哈希并换取官方 Token
        binding.btnDirectLogin.setOnClickListener {
            val account = binding.etAccount.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val isChina = binding.rbChina.isChecked

            if (account.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "请输入高驰登录账号和密码", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performDirectCorosLogin(account, password, isChina)
        }

        // 方式 2：手动粘贴 Token（内置强力智能格式清洗）
        binding.btnSaveManualToken.setOnClickListener {
            val rawToken = binding.etManualToken.text.toString()
            val cleanToken = sanitizeToken(rawToken)

            if (cleanToken.isEmpty()) {
                Toast.makeText(this, "请输入有效的 Access Token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            saveTokenAndFinish(cleanToken, "Token 已清洗并保存成功！")
        }
    }

    private fun performDirectCorosLogin(account: String, pass: String, isChina: Boolean) {
        binding.btnDirectLogin.isEnabled = false
        binding.loginProgress.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val baseUrl = if (isChina) "https://teamcnapi.coros.com" else "https://teamapi.coros.com"
                    val loginUrl = "$baseUrl/account/login"

                    val md5Pwd = md5(pass)
                    val jsonBody = JsonObject().apply {
                        addProperty("account", account)
                        addProperty("pwd", md5Pwd)
                        addProperty("accountType", 2)
                    }

                    val body = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                    val req = Request.Builder()
                        .url(loginUrl)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .post(body)
                        .build()

                    client.newCall(req).execute().use { resp ->
                        val bodyStr = resp.body?.string() ?: return@withContext Pair(false, "服务器无响应")
                        val root = try {
                            gson.fromJson(bodyStr, JsonObject::class.java)
                        } catch (e: Exception) {
                            null
                        }

                        var token: String? = null

                        // 1. 从响应头或 Set-Cookie 中提取
                        val headerToken = resp.header("accesstoken") ?: resp.header("AccessToken")
                        if (!headerToken.isNullOrBlank()) {
                            token = headerToken
                        } else {
                            for (c in resp.headers("Set-Cookie")) {
                                if (c.contains("CPL-coros-token=")) {
                                    token = c.substringAfter("CPL-coros-token=").substringBefore(";").trim()
                                    break
                                }
                            }
                        }

                        // 2. 从 JSON 树中逐级提取 Token
                        if (root != null) {
                            if (token.isNullOrBlank()) {
                                for (key in listOf("accessToken", "accesstoken", "token", "tokenString", "access_token")) {
                                    if (root.has(key) && !root.get(key).isJsonNull) {
                                        token = root.get(key).asString
                                        break
                                    }
                                }
                            }

                            if (token.isNullOrBlank() && root.has("data") && !root.get("data").isJsonNull) {
                                val dataElem = root.get("data")
                                if (dataElem.isJsonPrimitive) {
                                    token = dataElem.asString
                                } else if (dataElem.isJsonObject) {
                                    val dataObj = dataElem.asJsonObject
                                    for (key in listOf("accessToken", "accesstoken", "token", "cplToken", "tokenString", "access_token")) {
                                        if (dataObj.has(key) && !dataObj.get(key).isJsonNull) {
                                            token = dataObj.get(key).asString
                                            break
                                        }
                                    }
                                }
                            }
                        }

                        // 2.5 正则深度兜底扫描 (针对任意层级的 JWT 或 16-64位 Token 字符串)
                        if (token.isNullOrBlank()) {
                            val jwtMatch = Regex("""eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+""").find(bodyStr)
                            if (jwtMatch != null) {
                                token = jwtMatch.value
                            } else {
                                val tokenMatch = Regex("""(?i)"(?:accessToken|accesstoken|token|cplToken)"\s*:\s*"([a-zA-Z0-9_-]{16,64})"""").find(bodyStr)
                                if (tokenMatch != null) {
                                    token = tokenMatch.groupValues[1]
                                }
                            }
                        }

                        // 3. 提取到合法 Token 时，判定登录成功
                        if (!token.isNullOrBlank()) {
                            return@withContext Pair(true, token)
                        }

                        // 4. 未提取到 Token 时展示服务端返回信息
                        val msg = root?.get("message")?.asString 
                            ?: root?.get("msg")?.asString 
                            ?: "登录未成功 (返回: $bodyStr)"

                        if (msg.equals("ok", ignoreCase = true)) {
                            Pair(false, "登录成功但返回格式特殊: $bodyStr")
                        } else {
                            Pair(false, msg)
                        }
                    }
                } catch (e: Exception) {
                    Pair(false, "网络连接失败: ${e.message}")
                }
            }

            binding.btnDirectLogin.isEnabled = true
            binding.loginProgress.visibility = View.GONE

            if (result.first) {
                // 登录成功：保存 Token、显示提示并立即关闭登录页跳转回主界面
                saveTokenAndFinish(result.second, "🎉 高驰账号登录成功，已自动绑定！")
            } else {
                Toast.makeText(this@LoginActivity, result.second, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sanitizeToken(raw: String): String {
        var t = raw.trim()
        if (t.equals("TEST_TOKEN", ignoreCase = true)) return "TEST_TOKEN"

        if (t.contains("CPL-coros-token=")) {
            t = t.substringAfter("CPL-coros-token=").substringBefore(";").trim()
        }

        t = t.replace(Regex("^(?i)(accesstoken|access_token|token|authorization|bearer)[\\s:=]+"), "")
        t = t.trim('"', '\'', '`', ' ', '\n', '\r', '\t', ';')

        return t
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun saveTokenAndFinish(token: String, msg: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACCESS_TOKEN, token)
            .apply()

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        finish() // 立即销毁登录页，自动返回主页并触发 onResume() 刷新状态
    }
}
