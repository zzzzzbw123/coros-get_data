package com.example.coroshealth.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.coroshealth.databinding.ActivityLoginBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    companion object {
        const val PREFS_NAME = "coros_auth"
        const val KEY_ACCESS_TOKEN = "access_token"
        const val KEY_BASE_URL = "coros_base_url"
        const val KEY_ACCOUNT = "coros_account"
        const val KEY_PWD_MD5 = "coros_pwd_md5"
        const val KEY_IS_CHINA = "coros_is_china"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedToken = prefs.getString(KEY_ACCESS_TOKEN, "")
        if (!savedToken.isNullOrBlank()) {
            binding.etManualToken.setText(savedToken)
        }

        binding.btnDirectLogin.setOnClickListener {
            val account = binding.etAccount.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val isChina = binding.rbChina.isChecked

            if (account.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "请输入高驰登录账号和密码", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performDirectCorosLogin(account, password, isChina)
        }

        binding.btnSaveManualToken.setOnClickListener {
            val rawToken = binding.etManualToken.text.toString()
            val cleanToken = sanitizeToken(rawToken)
            val isChina = binding.rbChina.isChecked
            val baseUrl = if (isChina) "https://teamcnapi.coros.com" else "https://teamapi.coros.com"

            if (cleanToken.isEmpty()) {
                Toast.makeText(this, "请输入有效的 Access Token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            saveTokenAndFinish(cleanToken, baseUrl, "Token 已清洗并保存成功！")
        }
    }

    private fun performDirectCorosLogin(account: String, pass: String, isChina: Boolean) {
        binding.btnDirectLogin.isEnabled = false
        binding.loginProgress.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                // 尝试登录并即时校验数据接口
                val preferredUrl = if (isChina) "https://teamcnapi.coros.com" else "https://teamapi.coros.com"
                val alternateUrl = if (isChina) "https://teamapi.coros.com" else "https://teamcnapi.coros.com"
                val candidateUrls = listOf(preferredUrl, alternateUrl)

                val md5Pwd = md5(pass)
                var lastErr = ""

                for (baseUrl in candidateUrls) {
                    try {
                        val loginUrl = "$baseUrl/account/login"
                        val jsonBody = JsonObject().apply {
                            addProperty("account", account)
                            addProperty("pwd", md5Pwd)
                            addProperty("accountType", 2)
                        }

                        val body = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                        val req = Request.Builder()
                            .url(loginUrl)
                            .header("Content-Type", "application/json")
                            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                            .post(body)
                            .build()

                        var token: String? = null
                        var loginResponseStr = ""

                        client.newCall(req).execute().use { resp ->
                            loginResponseStr = resp.body?.string() ?: ""
                            val root = try {
                                gson.fromJson(loginResponseStr, JsonObject::class.java)
                            } catch (e: Exception) {
                                null
                            }

                            // 1. 优先提取 JSON 响应体 data.accessToken
                            if (root != null && root.has("data") && !root.get("data").isJsonNull) {
                                val dataElem = root.get("data")
                                if (dataElem.isJsonObject) {
                                    val dataObj = dataElem.asJsonObject
                                    for (k in listOf("accessToken", "accesstoken", "token")) {
                                        if (dataObj.has(k) && !dataObj.get(k).isJsonNull) {
                                            token = dataObj.get(k).asString
                                            break
                                        }
                                    }
                                } else if (dataElem.isJsonPrimitive) {
                                    token = dataElem.asString
                                }
                            }

                            // 2. 正则全文查找 accessToken
                            if (token.isNullOrBlank()) {
                                val m = Regex("""(?i)"(?:accessToken|accesstoken|token)"\s*:\s*"([a-zA-Z0-9_-]{16,64})"""").find(loginResponseStr)
                                if (m != null) token = m.groupValues[1]
                            }

                            // 3. 从 Cookie / Header 兜底
                            if (token.isNullOrBlank()) {
                                token = resp.header("accesstoken")
                                if (token.isNullOrBlank()) {
                                    for (c in resp.headers("Set-Cookie")) {
                                        if (c.contains("CPL-coros-token=")) {
                                            token = c.substringAfter("CPL-coros-token=").substringBefore(";").trim()
                                            break
                                        }
                                    }
                                }
                            }
                        }

                        // 如果获取到了 Token，立即在现场用数据接口进行双向实测校验！
                        if (!token.isNullOrBlank()) {
                            val testResult = testTokenAgainstDataApi(baseUrl, token!!)
                            if (testResult.first) {
                                // 节点与Token完全匹配成功！
                                return@withContext Triple(true, token!!, baseUrl)
                            } else {
                                // 尝试用这个 Token 请求备用节点
                                val otherUrl = if (baseUrl == preferredUrl) alternateUrl else preferredUrl
                                val testOther = testTokenAgainstDataApi(otherUrl, token!!)
                                if (testOther.first) {
                                    return@withContext Triple(true, token!!, otherUrl)
                                }
                                lastErr = "登录成功但数据接口校验失败: ${testResult.second}"
                            }
                        } else {
                            lastErr = "登录返回未包含 Token: $loginResponseStr"
                        }
                    } catch (e: Exception) {
                        lastErr = "连接 $baseUrl 异常: ${e.message}"
                    }
                }

                Triple(false, "", lastErr)
            }

            binding.btnDirectLogin.isEnabled = true
            binding.loginProgress.visibility = View.GONE

            if (result.first) {
                // 校验完全通过才保存并跳转；同时保存账号凭据，供 Token 过期后自动静默重登
                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_ACCOUNT, account)
                    .putString(KEY_PWD_MD5, md5(pass))
                    .putBoolean(KEY_IS_CHINA, isChina)
                    .apply()
                saveTokenAndFinish(result.second, result.third, "🎉 高驰账号验证成功，已自动绑定并连通数据！")
            } else {
                MaterialAlertDialogBuilder(this@LoginActivity)
                    .setTitle("登录验证未通过")
                    .setMessage(result.third)
                    .setPositiveButton("好的", null)
                    .show()
            }
        }
    }

    /**
     * 实测 Token 是否能真正拉取高驰数据
     */
    private fun testTokenAgainstDataApi(baseUrl: String, token: String): Pair<Boolean, String> {
        return try {
            val testUrl = "$baseUrl/activity/query?size=5&pageNumber=1&modeList="
            val req = Request.Builder()
                .url(testUrl)
                .header("accesstoken", token)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                val root = gson.fromJson(body, JsonObject::class.java)
                val code = root?.get("code")?.asString ?: root?.get("apiCode")?.asString
                if (code == "0000") {
                    Pair(true, "OK")
                } else {
                    val msg = root?.get("message")?.asString ?: root?.get("msg")?.asString ?: body
                    Pair(false, "$baseUrl 返回: $msg")
                }
            }
        } catch (e: Exception) {
            Pair(false, "测试异常: ${e.message}")
        }
    }

    private fun sanitizeToken(raw: String): String {
        var t = raw.trim()
        if (t.equals("TEST_TOKEN", ignoreCase = true)) return "TEST_TOKEN"

        if (t.contains("CPL-coros-token=")) {
            t = t.substringAfter("CPL-coros-token=").substringBefore(";").trim()
        }

        t = t.replace(Regex("^(?i)(accesstoken|access_token|token|authorization|bearer)[\\s:=]+"), "")
        t = t.trim('"', '\'', '`', ' ', '\n', '\r', '\t', ';')

        return t
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun saveTokenAndFinish(token: String, baseUrl: String, msg: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACCESS_TOKEN, token)
            .putString(KEY_BASE_URL, baseUrl)
            .apply()

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        finish()
    }
}
