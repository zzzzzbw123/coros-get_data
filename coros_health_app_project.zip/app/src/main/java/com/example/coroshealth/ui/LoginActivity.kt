package com.example.coroshealth.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coroshealth.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    companion object {
        const val PREFS_NAME = "coros_auth"
        const val KEY_ACCESS_TOKEN = "access_token"

        // 高驰 MCP OAuth 2.0 授权端点
        const val COROS_OAUTH_AUTH_URL = "https://mcp.coros.com/mcp?action=authorize&client_id=coros_app&redirect_uri=corosapp://oauth/callback&response_type=token"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val savedToken = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACCESS_TOKEN, "")
        if (!savedToken.isNullOrBlank()) {
            binding.etManualToken.setText(savedToken)
        }

        // 按钮1：拉起浏览器/WebView 进行 OAuth 2.0 授权
        binding.btnOAuthLogin.setOnClickListener {
            openOAuthInBrowser()
        }

        // 按钮2：保存手动填写的 Token（方便快速测试与直接输入）
        binding.btnSaveManualToken.setOnClickListener {
            val token = binding.etManualToken.text.toString().trim()
            if (token.isEmpty()) {
                Toast.makeText(this, "请输入或粘贴 Access Token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveTokenAndFinish(token)
        }

        // 检查 Intent 是否携带授权重定向 Callback
        handleOAuthCallback(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleOAuthCallback(intent)
    }

    private fun openOAuthInBrowser() {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(COROS_OAUTH_AUTH_URL))
        try {
            startActivity(browserIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "无法拉起浏览器，请直接粘贴 Token", Toast.LENGTH_LONG).show()
        }
    }

    private fun handleOAuthCallback(intent: Intent?) {
        val data: Uri? = intent?.data
        if (data != null && data.scheme == "corosapp" && data.host == "oauth") {
            // 解析回调中的 access_token 或 code
            val fragment = data.fragment
            var token: String? = null

            if (!fragment.isNullOrBlank()) {
                val params = fragment.split("&")
                for (p in params) {
                    val pair = p.split("=")
                    if (pair.size == 2 && pair[0] == "access_token") {
                        token = pair[1]
                        break
                    }
                }
            }
            if (token == null) {
                token = data.getQueryParameter("code") ?: data.getQueryParameter("access_token")
            }

            if (!token.isNullOrBlank()) {
                saveTokenAndFinish(token)
            }
        }
    }

    private fun saveTokenAndFinish(token: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACCESS_TOKEN, token)
            .apply()

        Toast.makeText(this, "高驰账号授权成功！", Toast.LENGTH_SHORT).show()
        finish()
    }
}
