package com.example.coroshealth.data

import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import com.example.coroshealth.data.model.LapDetail
import com.example.coroshealth.data.model.TrackPoint
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class CorosMcpClient(
    private val accessToken: String?,
    private val customBaseUrl: String? = null,
    private val userId: String? = null
) {

    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val baseUrls = if (!customBaseUrl.isNullOrBlank()) {
        val alt = if (customBaseUrl.contains("cn")) "https://teamapi.coros.com" else "https://teamcnapi.coros.com"
        listOf(customBaseUrl, alt)
    } else {
        listOf("https://teamcnapi.coros.com", "https://teamapi.coros.com")
    }

    data class FetchResult(
        val isRealData: Boolean,
        val message: String,
        val healthRecords: List<DailyHealthRecord>,
        val activities: List<ActivityRecord>
    )

    suspend fun fetchData(startDate: String, endDate: String): FetchResult {
        return withContext(Dispatchers.IO) {
            val cleanStart = startDate.replace("-", "")
            val cleanEnd = endDate.replace("-", "")

            var token = (accessToken ?: "").trim()
            if (token.contains("CPL-coros-token=")) {
                token = token.substringAfter("CPL-coros-token=").substringBefore(";").trim()
            }
            token = token.replace(Regex("^(?i)(accesstoken|access_token|token|authorization|bearer)[\\s:=]+"), "")
            token = token.trim('"', '\'', '`', ' ', '\n', '\r', '\t', ';')

            if (token.isEmpty() || token.equals("TEST_TOKEN", ignoreCase = true)) {
                val sample = generateSampleCorosData(startDate, endDate)
                return@withContext FetchResult(
                    isRealData = false,
                    message = "当前为【演示示例数据】。请在顶部设置输入高驰账号密码绑定。",
                    healthRecords = sample.first,
                    activities = sample.second
                )
            }

            var tokenValid = false
            var foundActivities: List<ActivityRecord>? = null
            var lastErrorMessage = ""
            var matchedBaseUrl = baseUrls.first()

            // 1. 查询运动列表 (/activity/query)
            for (baseUrl in baseUrls) {
                try {
                    val queryUrl = "$baseUrl/activity/query?size=50&pageNumber=1&startDay=$cleanStart&endDay=$cleanEnd&modeList="

                    val req = Request.Builder()
                        .url(queryUrl)
                        .header("accesstoken", token)
                        .header("Cookie", "gray=th-v2; CPL-coros-token=$token")
                        .header("yfheader", "{\"userId\":\"${userId ?: ""}\"}")
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .get()
                        .build()

                    client.newCall(req).execute().use { resp ->
                        val code = resp.code
                        if (code == 401 || code == 403) {
                            lastErrorMessage = "登录凭证已失效 (HTTP $code)"
                            return@use
                        }

                        val bodyStr = resp.body?.string() ?: return@use
                        val root = gson.fromJson(bodyStr, JsonObject::class.java) ?: return@use
                        val apiCode = root.get("code")?.asString 
                            ?: root.get("result")?.asString 
                            ?: root.get("apiCode")?.asString

                        if (apiCode == "0000" && root.has("data")) {
                            tokenValid = true
                            matchedBaseUrl = baseUrl
                            val dataObj = root.getAsJsonObject("data")
                            val dataList = dataObj.getAsJsonArray("dataList")
                            val actList = mutableListOf<ActivityRecord>()

                            if (dataList != null && dataList.size() > 0) {
                                for (elem in dataList) {
                                    val item = elem.asJsonObject
                                    val labelId = item.get("labelId")?.asString ?: UUID.randomUUID().toString()
                                    val sportType = item.get("sportType")?.asInt ?: 100
                                    val sportName = parseSportName(sportType)

                                    val startTimestamp = item.get("startTime")?.asLong ?: (System.currentTimeMillis() / 1000)
                                    val startTimeStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                                        .format(Date(if (startTimestamp > 100000000000L) startTimestamp else startTimestamp * 1000))

                                    val distanceMeters = item.get("distance")?.asDouble ?: 0.0
                                    val totalTimeSec = item.get("totalTime")?.asInt
                                        ?: item.get("duration")?.asInt
                                        ?: 0

                                    val avgHr = item.get("avgHr")?.asInt
                                        ?: item.get("avgHeartRate")?.asInt
                                        ?: 0

                                    val maxHr = item.get("maxHr")?.asInt
                                        ?: item.get("maxHeartRate")?.asInt
                                        ?: 0

                                    val calories = item.get("calorie")?.asInt
                                        ?: item.get("calories")?.asInt
                                        ?: 0

                                    val paceSec = if (distanceMeters > 0) (totalTimeSec / (distanceMeters / 1000.0)).toInt() else 0
                                    val paceStr = if (paceSec > 0) String.format("%02d:%02d/km", paceSec / 60, paceSec % 60) else "--"

                                    // ① 拉取真实单次运动详情（真实分段，绝不伪造）
                                    var realLaps = fetchRealLaps(baseUrl, token, labelId)
                                    if (realLaps.isEmpty()) {
                                        // 备选尝试读取列表返回的 lapList
                                        realLaps = parseLapsFromItem(item)
                                    }

                                    // ② 下载单次运动 FIT 原始文件并解析秒级轨迹点（配速/心率随时间变化）
                                    val fitBytes = downloadFit(baseUrl, token, labelId)
                                    val trackPoints = if (fitBytes != null) FitParser.parse(fitBytes) else emptyList()

                                    actList.add(
                                        ActivityRecord(
                                            activityId = labelId,
                                            sportName = sportName,
                                            startTime = startTimeStr,
                                            distanceKm = Math.round(distanceMeters / 10.0) / 100.0,
                                            durationMinutes = Math.round(totalTimeSec / 6.0) / 10.0,
                                            avgPaceFormatted = paceStr,
                                            avgHeartRate = avgHr,
                                            maxHeartRate = maxHr,
                                            calories = calories,
                                            laps = realLaps,
                                            trackPoints = trackPoints
                                        )
                                    )
                                }
                            }
                            foundActivities = actList
                            return@use
                        } else {
                            val msg = root.get("message")?.asString ?: root.get("msg")?.asString ?: "接口代码: $apiCode"
                            lastErrorMessage = msg
                        }
                    }
                } catch (e: Exception) {
                    lastErrorMessage = e.message ?: "网络超时"
                }

                if (tokenValid && foundActivities != null) {
                    break
                }
            }

            if (tokenValid && foundActivities != null) {
                val realActivities = foundActivities!!

                // ③ 请求真实日常健康数据 (/analyse/dayDetail/query)
                val healthList = fetchDailyHealth(matchedBaseUrl, token, startDate, endDate).toMutableList()

                // 若当天健康数据尚未生成，补充一条空项占位，避免表格无数据
                if (healthList.isEmpty()) {
                    healthList.add(
                        DailyHealthRecord(
                            date = startDate,
                            restingHeartRate = -1,
                            sleepDurationMinutes = -1,
                            hrvValue = -1,
                            stressAvg = -1,
                            steps = -1,
                            trainingLoad = -1.0
                        )
                    )
                }

                val hasTrackPoints = realActivities.any { it.trackPoints.isNotEmpty() }
                val statusMsg = if (realActivities.isNotEmpty()) {
                    val trackDesc = if (hasTrackPoints) "含秒级心率/配速轨迹" else "分段明细已同步"
                    "✅ 成功从高驰拉取到 ${realActivities.size} 次真实运动（${trackDesc}）及真实健康数据！"
                } else {
                    "✅ 高驰账号连通成功！在 ${startDate} 至 ${endDate} 暂无运动记录，可点击快捷标签查看近30天。"
                }

                return@withContext FetchResult(
                    isRealData = true,
                    message = statusMsg,
                    healthRecords = healthList,
                    activities = realActivities
                )
            }

            val sample = generateSampleCorosData(startDate, endDate)
            return@withContext FetchResult(
                isRealData = false,
                message = "⚠️ 高驰 Token 验证未通过 (${lastErrorMessage})。请检查账号区域 (国内/海外) 并重新登录。",
                healthRecords = sample.first,
                activities = sample.second
            )
        }
    }

    /**
     * 调用单次运动详情接口：/activity/detail/query?labelId=xxx 获取真实分段
     */
    private fun fetchRealLaps(baseUrl: String, token: String, labelId: String): List<LapDetail> {
        val laps = mutableListOf<LapDetail>()
        try {
            val req = Request.Builder()
                .url("$baseUrl/activity/detail/query?labelId=$labelId")
                .header("accesstoken", token)
                .header("Cookie", "gray=th-v2; CPL-coros-token=$token")
                .header("yfheader", "{\"userId\":\"${userId ?: ""}\"}")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string() ?: return laps
                val root = gson.fromJson(bodyStr, JsonObject::class.java) ?: return laps
                val apiCode = root.get("code")?.asString 
                    ?: root.get("result")?.asString 
                    ?: root.get("apiCode")?.asString
                if (apiCode != "0000") return laps

                val data = root.getAsJsonObject("data") ?: return laps
                val arr = data.getAsJsonArray("lapList") ?: return laps

                for ((idx, el) in arr.withIndex()) {
                    val l = el.asJsonObject
                    val dist = l.get("distance")?.asDouble ?: 0.0
                    val time = l.get("totalTime")?.asInt ?: l.get("time")?.asInt ?: 0
                    val avgSpeed = l.get("avgSpeed")?.asDouble ?: 0.0 // 米/秒
                    val paceSec = if (avgSpeed > 0) (1000.0 / avgSpeed).toInt() else if (dist > 0 && time > 0) (time / (dist / 1000.0)).toInt() else 0
                    val paceFormatted = if (paceSec > 0) String.format("%02d:%02d/km", paceSec / 60, paceSec % 60) else "--"

                    laps.add(
                        LapDetail(
                            lapIndex = l.get("lap")?.asInt ?: (idx + 1),
                            distanceMeters = dist,
                            durationSeconds = time,
                            paceFormatted = paceFormatted,
                            avgHeartRate = l.get("avgHr")?.asInt ?: 0,
                            maxHeartRate = l.get("maxHr")?.asInt ?: 0,
                            cadenceSprm = l.get("avgCadence")?.asInt ?: l.get("cadence")?.asInt ?: 0,
                            elevationGainMeters = l.get("ascent")?.asDouble ?: l.get("elevation")?.asDouble ?: 0.0
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return laps
    }

    /**
     * 下载 FIT 原始二进制文件：/activity/fit/download?labelId=xxx
     */
    fun downloadFit(baseUrl: String, token: String, labelId: String): ByteArray? {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/activity/fit/download?labelId=$labelId")
                .header("accesstoken", token)
                .header("Cookie", "gray=th-v2; CPL-coros-token=$token")
                .header("yfheader", "{\"userId\":\"${userId ?: ""}\"}")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) resp.body?.bytes() else null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 获取真实日常健康数据：/analyse/dayDetail/query?startDay=xxx&endDay=xxx
     * 获取真实的静息心率 (rhr)、训练负荷 (trainingLoad)、HRV (avgSleepHrv)
     */
    private fun fetchDailyHealth(baseUrl: String, token: String, startDate: String, endDate: String): List<DailyHealthRecord> {
        val list = mutableListOf<DailyHealthRecord>()
        try {
            val s = startDate.replace("-", "")
            val e = endDate.replace("-", "")
            val req = Request.Builder()
                .url("$baseUrl/analyse/dayDetail/query?startDay=$s&endDay=$e")
                .header("accesstoken", token)
                .header("Cookie", "gray=th-v2; CPL-coros-token=$token")
                .header("yfheader", "{\"userId\":\"${userId ?: ""}\"}")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string() ?: return list
                val root = gson.fromJson(bodyStr, JsonObject::class.java) ?: return list
                val apiCode = root.get("code")?.asString 
                    ?: root.get("result")?.asString 
                    ?: root.get("apiCode")?.asString
                if (apiCode != "0000") return list

                val data = root.getAsJsonObject("data") ?: return list
                val days = data.getAsJsonArray("dayList") ?: return list

                for (el in days) {
                    val d = el.asJsonObject
                    val dayStr = d.get("happenDay")?.asString
                    val formattedDate = if (dayStr != null && dayStr.length == 8) {
                        "${dayStr.substring(0, 4)}-${dayStr.substring(4, 6)}-${dayStr.substring(6, 8)}"
                    } else {
                        dayStr ?: startDate
                    }

                    list.add(
                        DailyHealthRecord(
                            date = formattedDate,
                            restingHeartRate = d.get("rhr")?.asInt ?: -1,
                            sleepDurationMinutes = -1,   // 网页端接口不提供，界面显示"—"
                            hrvValue = d.get("avgSleepHrv")?.asInt ?: -1,
                            stressAvg = -1,              // 网页端接口不提供，界面显示"—"
                            steps = -1,                  // 网页端接口不提供，界面显示"—"
                            trainingLoad = d.get("trainingLoad")?.asDouble ?: -1.0
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun parseLapsFromItem(item: JsonObject): List<LapDetail> {
        val laps = mutableListOf<LapDetail>()
        if (item.has("lapList") && item.get("lapList").isJsonArray) {
            val lapArray = item.getAsJsonArray("lapList")
            for (idx in 0 until lapArray.size()) {
                val lObj = lapArray.get(idx).asJsonObject
                val lIndex = lObj.get("lap")?.asInt ?: lObj.get("lapIndex")?.asInt ?: (idx + 1)
                val lDist = lObj.get("distance")?.asDouble ?: 1000.0
                val lTime = lObj.get("time")?.asInt ?: lObj.get("totalTime")?.asInt ?: 300
                val avgSpeed = lObj.get("avgSpeed")?.asDouble ?: 0.0
                val paceSec = if (avgSpeed > 0) (1000.0 / avgSpeed).toInt() else if (lDist > 0 && lTime > 0) (lTime / (lDist / 1000.0)).toInt() else 0
                val paceStr = if (paceSec > 0) String.format("%02d:%02d/km", paceSec / 60, paceSec % 60) else "--"

                laps.add(
                    LapDetail(
                        lapIndex = lIndex,
                        distanceMeters = lDist,
                        durationSeconds = lTime,
                        paceFormatted = paceStr,
                        avgHeartRate = lObj.get("avgHr")?.asInt ?: 0,
                        maxHeartRate = lObj.get("maxHr")?.asInt ?: 0,
                        cadenceSprm = lObj.get("cadence")?.asInt ?: lObj.get("avgCadence")?.asInt ?: 0,
                        elevationGainMeters = lObj.get("elevation")?.asDouble ?: lObj.get("ascent")?.asDouble ?: 0.0
                    )
                )
            }
        }
        return laps
    }

    private fun parseSportName(sportType: Int): String {
        return when (sportType) {
            100, 103 -> "户外跑步 (Outdoor Running)"
            101, 104 -> "跑步机 (Treadmill)"
            102 -> "越野跑 (Trail Running)"
            200, 202 -> "户外骑行 (Outdoor Cycling)"
            201 -> "室内骑行 (Indoor Cycling)"
            300 -> "泳池游泳 (Pool Swim)"
            301 -> "公开水域游泳 (Open Water)"
            400 -> "登山/徒步 (Hiking)"
            else -> "专项运动 ($sportType)"
        }
    }

    private fun generateSampleCorosData(startDate: String, endDate: String): Pair<List<DailyHealthRecord>, List<ActivityRecord>> {
        val healthList = listOf(
            DailyHealthRecord(
                date = startDate,
                restingHeartRate = 48,
                sleepDurationMinutes = -1,
                hrvValue = 72,
                stressAvg = -1,
                steps = -1,
                trainingLoad = 118.5
            )
        )

        val laps10k = listOf(
            LapDetail(1, 1000.0, 310, "05:10/km", 136, 142, 178, 2.0),
            LapDetail(2, 1000.0, 298, "04:58/km", 145, 149, 180, 1.5),
            LapDetail(3, 1000.0, 292, "04:52/km", 148, 153, 182, -1.0),
            LapDetail(4, 1000.0, 286, "04:46/km", 153, 157, 182, 0.0),
            LapDetail(5, 1000.0, 280, "04:40/km", 158, 162, 184, 3.0),
            LapDetail(6, 1000.0, 275, "04:35/km", 162, 166, 184, -2.0),
            LapDetail(7, 1000.0, 272, "04:32/km", 165, 169, 186, 1.0),
            LapDetail(8, 1000.0, 268, "04:28/km", 168, 172, 186, 0.0),
            LapDetail(9, 1000.0, 260, "04:20/km", 172, 176, 188, -1.5),
            LapDetail(10, 1000.0, 245, "04:05/km", 178, 183, 192, 0.5)
        )

        val sampleTrack = mutableListOf<TrackPoint>()
        val baseTs = System.currentTimeMillis() / 1000 - 3600
        for (i in 0 until 120) {
            sampleTrack.add(
                TrackPoint(
                    timestampSec = baseTs + i * 10,
                    heartRate = 140 + (i % 25),
                    speedMps = 3.6 + (i % 5) * 0.1,
                    cadence = 180 + (i % 4),
                    altitude = 50.0 + (i % 10) * 0.5,
                    distanceM = i * 36.0
                )
            )
        }

        val activities = listOf(
            ActivityRecord(
                activityId = "coros_sample_act",
                sportName = "路跑 (演示数据)",
                startTime = "$startDate 06:45",
                distanceKm = 10.0,
                durationMinutes = 46.4,
                avgPaceFormatted = "04:38/km",
                avgHeartRate = 158,
                maxHeartRate = 183,
                calories = 680,
                laps = laps10k,
                trackPoints = sampleTrack
            )
        )
        return Pair(healthList, activities)
    }
}
