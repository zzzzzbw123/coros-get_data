package com.example.coroshealth.data.model

/**
 * 每秒/高频轨迹点（从 FIT 原始文件解析，用于心率/配速随时间变化深度分析）
 */
data class TrackPoint(
    val timestampSec: Long,   // Unix 秒时间戳
    val heartRate: Int,       // 心率 bpm, -1 表示无效/未佩戴
    val speedMps: Double,     // 速度 米/秒
    val cadence: Int,         // 步频/踏频 spm, -1 表示无效
    val altitude: Double,     // 海拔 高度(米)
    val distanceM: Double     // 累计距离(米)
)

/**
 * 日常健康数据模型
 */
data class DailyHealthRecord(
    val date: String,              // YYYY-MM-DD
    val restingHeartRate: Int,      // 静息心率 (bpm), -1 表示无数据
    val sleepDurationMinutes: Int,  // 睡眠时长 (分钟), -1 表示接口不提供
    val hrvValue: Int,             // HRV 心率变异性 (ms), -1 表示无数据
    val stressAvg: Int,            // 日间平均压力指数 (0-100), -1 表示接口不提供
    val steps: Int,                // 全天步数, -1 表示接口不提供
    val trainingLoad: Double,      // 训练负荷, -1.0 表示无数据
    val testRhr: Int = -1,         // 手动测量的静息心率 (对照用)
    val sleepDeepMinutes: Int = -1,
    val sleepLightMinutes: Int = -1,
    val sleepRemMinutes: Int = -1,
    val sleepScore: Int = -1
)

/**
 * 单次运动记录总览
 */
data class ActivityRecord(
    val activityId: String,
    val sportName: String,         // 跑步、越野跑、骑行等
    val startTime: String,         // 开始时间
    val distanceKm: Double,        // 总距离 (公里)
    val durationMinutes: Double,   // 总时长 (分钟)
    val avgPaceFormatted: String,  // 平均配速 (如 "04:35/km")
    val avgHeartRate: Int,         // 平均心率 (bpm)
    val maxHeartRate: Int,         // 最大心率 (bpm)
    val calories: Int,             // 消耗卡路里
    val laps: List<LapDetail> = emptyList(), // 真实分段/分圈数据
    val trackPoints: List<TrackPoint> = emptyList() // 每秒详细轨迹点
)

/**
 * 运动分段明细（每公里/每圈配速、心率、步频）
 */
data class LapDetail(
    val lapIndex: Int,             // 第几圈/第几段
    val distanceMeters: Double,    // 该段距离 (米)
    val durationSeconds: Int,      // 该段用时 (秒)
    val paceFormatted: String,     // 分段配速 (如 "04:32/km")
    val avgHeartRate: Int,         // 分段平均心率 (bpm)
    val maxHeartRate: Int,         // 分段最高心率 (bpm)
    val cadenceSprm: Int,          // 步频 (spm)
    val elevationGainMeters: Double// 爬升 (米)
)

/**
 * JSON-RPC 2.0 请求格式 (用于 COROS MCP 官方协议备用)
 */
data class JsonRpcRequest(
    val jsonrpc: String = "2.0",
    val id: String,
    val method: String,
    val params: Map<String, Any> = emptyMap()
)

/**
 * JSON-RPC 2.0 响应格式
 */
data class JsonRpcResponse(
    val jsonrpc: String,
    val id: String?,
    val result: Map<String, Any>?,
    val error: Map<String, Any>?
)
