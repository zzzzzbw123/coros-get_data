package com.example.coroshealth.data.model

import com.google.gson.annotations.SerializedName

/**
 * 日常健康数据模型
 */
data class DailyHealthRecord(
    val date: String,              // YYYY-MM-DD
    val restingHeartRate: Int,      // 静息心率 (bpm)
    val sleepDurationMinutes: Int,  // 睡眠时长 (分钟)
    val hrvValue: Int,             // HRV 心率变异性 (ms)
    val stressAvg: Int,            // 日间平均压力指数 (0-100)
    val steps: Int,                // 全天步数
    val trainingLoad: Double       // 训练负荷
)

/**
 * 单次运动记录总览
 */
data class ActivityRecord(
    val activityId: String,
    val sportName: String,         // 跑步、越野跑、骑行等
    val startTime: String,         // 开始时间
    val distanceKm: Double,        // 总距离 (公里)
    val durationMinutes: Double,   // 总时长 (分钟)
    val avgPaceFormatted: String,  // 平均配速 (如 "04'45\"")
    val avgHeartRate: Int,         // 平均心率 (bpm)
    val maxHeartRate: Int,         // 最大心率 (bpm)
    val calories: Int,             // 消耗卡路里
    val laps: List<LapDetail> = emptyList() // 分段/分圈数据
)

/**
 * 运动分段明细（每公里/每圈配速、心率、步频）
 */
data class LapDetail(
    val lapIndex: Int,             // 第几圈/第几公里
    val distanceMeters: Double,    // 该段距离 (米)
    val durationSeconds: Int,      // 该段用时 (秒)
    val paceFormatted: String,     // 分段配速 (如 "04'32\"/km")
    val avgHeartRate: Int,         // 分段平均心率 (bpm)
    val maxHeartRate: Int,         // 分段最高心率 (bpm)
    val cadenceSprm: Int,          // 步频 (spm)
    val elevationGainMeters: Double// 爬升 (米)
)

/**
 * JSON-RPC 2.0 请求格式 (用于 COROS MCP 官方协议)
 */
data class JsonRpcRequest(
    val jsonrpc: String = "2.0",
    val id: String,
    val method: String,
    val params: Map<String, Any> = emptyMap()
)

/**
 * JSON-RPC 2.0 响应格式
 */
data class JsonRpcResponse(
    val jsonrpc: String,
    val id: String?,
    val result: Map<String, Any>?,
    val error: Map<String, Any>?
)
