package com.example.coroshealth.data

import android.content.Context
import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

object CsvExporter {

    /**
     * 导出包含分段配速和心率的完整 CSV 表格
     */
    fun exportToCsvFile(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): File {
        val file = File(context.cacheDir, "coros_health_and_sports_export.csv")
        FileOutputStream(file).use { fos ->
            OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                // 写入 UTF-8 BOM，确保 Excel / WPS 打开中文时不乱码
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))

                // 1. 日常健康数据表
                writer.append("=== 高驰日常健康数据表 ===\n")
                writer.append("日期,静息心率(bpm),睡眠时长(分钟),HRV心率变异性(ms),平均压力(0-100),步数,训练负荷\n")
                for (h in healthList) {
                    writer.append("${h.date},${h.restingHeartRate},${h.sleepDurationMinutes},${h.hrvValue},${h.stressAvg},${h.steps},${h.trainingLoad}\n")
                }
                writer.append("\n\n")

                // 2. 运动记录总览表
                writer.append("=== 高驰运动记录总览表 ===\n")
                writer.append("运动ID,运动类型,开始时间,总距离(km),总耗时(分),平均配速,平均心率(bpm),最高心率(bpm),卡路里(kcal)\n")
                for (a in activities) {
                    writer.append("${a.activityId},${a.sportName},${a.startTime},${a.distanceKm},${a.durationMinutes},${a.avgPaceFormatted},${a.avgHeartRate},${a.maxHeartRate},${a.calories}\n")
                }
                writer.append("\n\n")

                // 3. 极尽详细的单圈/分段配速与心率明细表
                writer.append("=== 详细分段运动数据表 (分段配速/心率/步频) ===\n")
                writer.append("运动ID,分段序号,分段距离(米),分段耗时(秒),分段配速(分秒/km),分段平均心率(bpm),分段最高心率(bpm),步频(spm),爬升(米)\n")
                for (a in activities) {
                    for (lap in a.laps) {
                        writer.append("${a.activityId},第${lap.lapIndex}段,${lap.distanceMeters},${lap.durationSeconds},${lap.paceFormatted},${lap.avgHeartRate},${lap.maxHeartRate},${lap.cadenceSprm},${lap.elevationGainMeters}\n")
                    }
                }
                writer.flush()
            }
        }
        return file
    }
}
