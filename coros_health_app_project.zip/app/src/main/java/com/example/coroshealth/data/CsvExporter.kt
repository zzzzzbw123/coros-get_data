package com.example.coroshealth.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets

object CsvExporter {

    fun generateCsvString(
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): String {
        val sb = StringBuilder()

        // 1. 日常健康数据表
        sb.append("=== 高驰日常健康数据表 ===\n")
        sb.append("日期,静息心率(bpm),睡眠时长(分钟),HRV心率变异性(ms),平均压力(0-100),步数,训练负荷\n")
        for (h in healthList) {
            sb.append("${h.date},${h.restingHeartRate},${h.sleepDurationMinutes},${h.hrvValue},${h.stressAvg},${h.steps},${h.trainingLoad}\n")
        }
        sb.append("\n\n")

        // 2. 运动记录总览表
        sb.append("=== 高驰运动记录总览表 ===\n")
        sb.append("运动ID,运动类型,开始时间,总距离(km),总耗时(分),平均配速,平均心率(bpm),最高心率(bpm),卡路里(kcal)\n")
        for (a in activities) {
            sb.append("${a.activityId},${a.sportName},${a.startTime},${a.distanceKm},${a.durationMinutes},${a.avgPaceFormatted},${a.avgHeartRate},${a.maxHeartRate},${a.calories}\n")
        }
        sb.append("\n\n")

        // 3. 详细分段运动数据表
        sb.append("=== 详细分段运动数据表 (分段配速/心率/步频) ===\n")
        sb.append("运动ID,分段序号,分段距离(米),分段耗时(秒),分段配速(分秒/km),分段平均心率(bpm),分段最高心率(bpm),步频(spm),爬升(米)\n")
        for (a in activities) {
            for (lap in a.laps) {
                sb.append("${a.activityId},第${lap.lapIndex}段,${lap.distanceMeters},${lap.durationSeconds},${lap.paceFormatted},${lap.avgHeartRate},${lap.maxHeartRate},${lap.cadenceSprm},${lap.elevationGainMeters}\n")
            }
        }
        return sb.toString()
    }

    /**
     * 保存到手机系统公共 Download (下载) 目录，用户可在文件管理器直接查看
     */
    fun saveToPublicDownloads(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>,
        fileName: String
    ): String? {
        val csvContent = generateCsvString(healthList, activities)
        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = csvContent.toByteArray(StandardCharsets.UTF_8)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                context.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(bom)
                    os.write(contentBytes)
                    os.flush()
                }
                return "手机【下载 (Download)】文件夹"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                val targetFile = File(dir, fileName)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(bom)
                    fos.write(contentBytes)
                    fos.flush()
                }
                return targetFile.absolutePath
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**
     * 导出为临时缓存文件，供微信、QQ、系统分享调用
     */
    fun exportToCsvFile(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): File {
        val file = File(context.cacheDir, "coros_health_and_sports_export.csv")
        val csvContent = generateCsvString(healthList, activities)
        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = csvContent.toByteArray(StandardCharsets.UTF_8)

        FileOutputStream(file).use { fos ->
            fos.write(bom)
            fos.write(contentBytes)
            fos.flush()
        }
        return file
    }
}
