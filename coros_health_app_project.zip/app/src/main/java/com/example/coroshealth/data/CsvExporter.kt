package com.example.coroshealth.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object CsvExporter {

    private val BOM = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())

    /**
     * 生成适合在 Excel / WPS 中查看的综合多表汇总 CSV
     */
    fun generateCsvString(
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): String {
        val sb = StringBuilder()

        // 1. 日常健康数据表
        sb.append("=== 高驰日常健康数据表 ===\n")
        sb.append("日期,静息心率(bpm),手动测量RHR,睡眠时长(分),深睡(分),浅睡(分),REM(分),睡眠评分,HRV心率变异性(ms),平均压力,全天步数,训练负荷\n")
        for (h in healthList) {
            val rhr = if (h.restingHeartRate >= 0) "${h.restingHeartRate}" else "—"
            val testRhr = if (h.testRhr >= 0) "${h.testRhr}" else "—"
            val sleep = if (h.sleepDurationMinutes >= 0) "${h.sleepDurationMinutes}" else "—"
            val sleepDeep = if (h.sleepDeepMinutes >= 0) "${h.sleepDeepMinutes}" else "—"
            val sleepLight = if (h.sleepLightMinutes >= 0) "${h.sleepLightMinutes}" else "—"
            val sleepRem = if (h.sleepRemMinutes >= 0) "${h.sleepRemMinutes}" else "—"
            val sleepScore = if (h.sleepScore >= 0) "${h.sleepScore}" else "—"
            val hrv = if (h.hrvValue >= 0) "${h.hrvValue}" else "—"
            val stress = if (h.stressAvg >= 0) "${h.stressAvg}" else "—"
            val steps = if (h.steps >= 0) "${h.steps}" else "—"
            val load = if (h.trainingLoad >= 0) "${h.trainingLoad}" else "—"
            sb.append("${h.date},$rhr,$testRhr,$sleep,$sleepDeep,$sleepLight,$sleepRem,$sleepScore,$hrv,$stress,$steps,$load\n")
        }
        sb.append("\n\n")

        // 2. 运动记录总览表
        sb.append("=== 高驰运动记录总览表 ===\n")
        sb.append("运动ID,运动类型,开始时间,总距离(km),总耗时(分),平均配速,平均心率(bpm),最高心率(bpm),卡路里(kcal),分段数,秒级轨迹点数\n")
        for (a in activities) {
            sb.append("${a.activityId},${a.sportName},${a.startTime},${a.distanceKm},${a.durationMinutes},${a.avgPaceFormatted},${a.avgHeartRate},${a.maxHeartRate},${a.calories},${a.laps.size},${a.trackPoints.size}\n")
        }
        sb.append("\n\n")

        // 3. 详细分段运动数据表（真实分段）
        sb.append("=== 详细分段运动数据表 (真实分段/分圈明细) ===\n")
        sb.append("运动ID,运动类型,分段序号,分段距离(米),分段耗时(秒),分段配速(分秒/km),分段平均心率(bpm),分段最高心率(bpm),步频(spm),爬升(米)\n")
        for (a in activities) {
            for (lap in a.laps) {
                sb.append("${a.activityId},${a.sportName},第${lap.lapIndex}段,${lap.distanceMeters},${lap.durationSeconds},${lap.paceFormatted},${lap.avgHeartRate},${lap.maxHeartRate},${lap.cadenceSprm},${lap.elevationGainMeters}\n")
            }
        }
        return sb.toString()
    }

    /**
     * 生成单次运动专供 AI 深度分析的标准 CSV（含 SUMMARY、LAPS、TRACK 秒级明细三段）
     */
    fun generateActivityAiAnalysisCsv(activity: ActivityRecord): String {
        val sb = StringBuilder()

        // 1. SUMMARY
        sb.append("# SUMMARY\n")
        sb.append("activity_id,sport,start_time,distance_km,duration_s,avg_hr,max_hr,calories\n")
        val durSec = (activity.durationMinutes * 60).toInt()
        sb.append("${activity.activityId},${activity.sportName},${activity.startTime},${activity.distanceKm},$durSec,${activity.avgHeartRate},${activity.maxHeartRate},${activity.calories}\n\n")

        // 2. LAPS
        sb.append("# LAPS\n")
        sb.append("lap,distance_m,time_s,pace,avg_hr,max_hr,cadence,ascent_m\n")
        for (l in activity.laps) {
            sb.append("${l.lapIndex},${l.distanceMeters},${l.durationSeconds},${l.paceFormatted},${l.avgHeartRate},${l.maxHeartRate},${l.cadenceSprm},${l.elevationGainMeters}\n")
        }
        sb.append("\n")

        // 3. TRACK (每秒数据)
        sb.append("# TRACK (秒级明细)\n")
        sb.append("elapsed_s,hr_bpm,pace_min_per_km,cadence_spm,altitude_m,distance_m\n")
        if (activity.trackPoints.isNotEmpty()) {
            val firstTs = activity.trackPoints.first().timestampSec
            for (p in activity.trackPoints) {
                val elapsed = Math.max(0L, p.timestampSec - firstTs)
                val paceMinPerKm = if (p.speedMps > 0.1) String.format(Locale.US, "%.2f", (1000.0 / p.speedMps) / 60.0) else "0.00"
                val hrStr = if (p.heartRate > 0) "${p.heartRate}" else "--"
                val cadStr = if (p.cadence > 0) "${p.cadence}" else "--"
                sb.append("$elapsed,$hrStr,$paceMinPerKm,$cadStr,${String.format(Locale.US, "%.1f", p.altitude)},${String.format(Locale.US, "%.1f", p.distanceM)}\n")
            }
        } else {
            sb.append("# 本次运动暂未抓取到秒级原始轨迹点，可参考上方 LAPS 分段数据\n")
        }

        return sb.toString()
    }

    /**
     * 保存综合表格到手机系统公共 Download (下载) 目录
     */
    fun saveToPublicDownloads(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>,
        fileName: String
    ): String? {
        val csvContent = generateCsvString(healthList, activities)
        val contentBytes = csvContent.toByteArray(StandardCharsets.UTF_8)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                context.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(BOM)
                    os.write(contentBytes)
                    os.flush()
                }
                return "手机【下载 (Download)】文件夹"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                val targetFile = File(dir, fileName)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(BOM)
                    fos.write(contentBytes)
                    fos.flush()
                }
                return targetFile.absolutePath
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**
     * 导出为临时缓存文件，供微信、QQ、系统分享调用
     */
    fun exportToCsvFile(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): File {
        val file = File(context.cacheDir, "coros_health_and_sports_export.csv")
        val csvContent = generateCsvString(healthList, activities)
        val contentBytes = csvContent.toByteArray(StandardCharsets.UTF_8)

        FileOutputStream(file).use { fos ->
            fos.write(BOM)
            fos.write(contentBytes)
            fos.flush()
        }
        return file
    }

    /**
     * 生成 AI 深度分析数据包 (ZIP 格式，包含每场运动的秒级数据 + 汇总表 + AI提示词)
     */
    fun exportAiAnalysisZip(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>
    ): File {
        val zipFile = File(context.cacheDir, "coros_ai_analysis_package.zip")
        if (zipFile.exists()) zipFile.delete()

        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            // 1. 添加总览表
            val summaryEntry = ZipEntry("00_综合健康与运动总览表.csv")
            zos.putNextEntry(summaryEntry)
            zos.write(BOM)
            zos.write(generateCsvString(healthList, activities).toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()

            // 2. 为每场运动添加专属 AI 分析 CSV（含秒级轨迹点与分段）
            for ((index, act) in activities.withIndex()) {
                val cleanDate = act.startTime.replace(":", "-").replace(" ", "_")
                val actFileName = String.format(Locale.getDefault(), "activity_%02d_%s_%s.csv", index + 1, cleanDate, act.sportName.take(6))
                val actEntry = ZipEntry(actFileName)
                zos.putNextEntry(actEntry)
                zos.write(BOM)
                zos.write(generateActivityAiAnalysisCsv(act).toByteArray(StandardCharsets.UTF_8))
                zos.closeEntry()
            }

            // 3. 添加 AI 分析指南与提示词
            val readmeEntry = ZipEntry("README_AI提示词指南.txt")
            zos.putNextEntry(readmeEntry)
            val readmeContent = """
                =======================================================
                高驰 (COROS) 运动与健康数据 - AI 深度分析数据包
                =======================================================
                
                本数据包由高驰运动健康助手自动导出，包含：
                1. 00_综合健康与运动总览表.csv: 日常静息心率、手动RHR、深度睡眠分期(深睡/浅睡/REM)、睡眠评分与训练负荷
                2. activity_XX_*.csv: 每次运动的独立文件，包含：
                   - SUMMARY: 运动基础指标总览
                   - LAPS: 真实分段数据（各阶段配速、分段心率、步频、爬升）
                   - TRACK: 秒级详细数据（时间戳、实时心率、实时配速、实时步频、海拔）
                
                【推荐发给 AI (Claude / ChatGPT / Gemini) 的提示词】：
                -------------------------------------------------------
                “你好！附件是我从高驰手表中导出的原始运动数据与健康数据。
                请帮我做一次专业、深入的跑步/训练分析：
                1. 针对每场运动的分段配速与心率曲线，评估配速衰减度与体能分配策略。
                2. 分析是否有明显的心率漂移（Cardiac Drift）现象，评估有氧耐力基础。
                3. 对比各分段的步频稳定性与心率恢复效率，指出当前的训练短板。
                4. 结合近期的静息心率和训练负荷，给出针对性的下一阶段训练与配速建议。”
                -------------------------------------------------------
            """.trimIndent()
            zos.write(readmeContent.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()
        }

        return zipFile
    }

    /**
     * 保存 AI 深度分析数据包 (ZIP) 到手机【下载】目录
     */
    fun saveAiAnalysisZipToDownloads(
        context: Context,
        healthList: List<DailyHealthRecord>,
        activities: List<ActivityRecord>,
        fileName: String
    ): String? {
        val zipFile = exportAiAnalysisZip(context, healthList, activities)
        val contentBytes = zipFile.readBytes()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                context.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(contentBytes)
                    os.flush()
                }
                return "手机【下载 (Download)】文件夹"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                val targetFile = File(dir, fileName)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(contentBytes)
                    fos.flush()
                }
                return targetFile.absolutePath
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
