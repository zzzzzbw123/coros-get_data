package com.example.coroshealth

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coroshealth.data.CorosMcpClient
import com.example.coroshealth.data.CsvExporter
import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import com.example.coroshealth.databinding.ActivityMainBinding
import com.example.coroshealth.ui.HealthTableAdapter
import com.example.coroshealth.ui.LapDetailAdapter
import com.example.coroshealth.ui.LoginActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val calendar = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    private var selectedStartDate: String = ""
    private var selectedEndDate: String = ""

    private var currentHealthData: List<DailyHealthRecord> = emptyList()
    private var currentActivities: List<ActivityRecord> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initDefaultDates()
        setupListeners()
        setupTabs()
        checkAuthStatus()
    }

    override fun onResume() {
        super.onResume()
        checkAuthStatus()
    }

    private fun initDefaultDates() {
        val todayStr = dateFormat.format(calendar.time)
        selectedStartDate = todayStr
        selectedEndDate = todayStr
        binding.tvStartDate.text = selectedStartDate
        binding.tvEndDate.text = selectedEndDate
    }

    private fun checkAuthStatus() {
        val prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(LoginActivity.KEY_ACCESS_TOKEN, "")
        if (token.isNullOrBlank()) {
            binding.tvAuthStatus.text = "⚠️ 未连接高驰账号 (点击设置)"
            binding.tvAuthStatus.setTextColor(getColor(R.color.coros_orange))
        } else if (token == "TEST_TOKEN") {
            binding.tvAuthStatus.text = "🧪 当前为测试示例模式 (点击换成真实 Token)"
            binding.tvAuthStatus.setTextColor(getColor(R.color.coros_accent_cyan))
        } else {
            binding.tvAuthStatus.text = "✅ 高驰真实账号已绑定 (点击可更换)"
            binding.tvAuthStatus.setTextColor(getColor(R.color.coros_accent_green))
        }
    }

    private fun setupListeners() {
        // 跳转登录 / Token 配置
        binding.cardAuthStatus.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        // 选择开始日期
        binding.btnSelectStartDate.setOnClickListener {
            showDatePicker { dateStr ->
                selectedStartDate = dateStr
                binding.tvStartDate.text = dateStr
            }
        }

        // 选择结束日期
        binding.btnSelectEndDate.setOnClickListener {
            showDatePicker { dateStr ->
                selectedEndDate = dateStr
                binding.tvEndDate.text = dateStr
            }
        }

        // 快速选择：今天
        binding.chipToday.setOnClickListener {
            val todayStr = dateFormat.format(Calendar.getInstance().time)
            selectedStartDate = todayStr
            selectedEndDate = todayStr
            binding.tvStartDate.text = todayStr
            binding.tvEndDate.text = todayStr
        }

        // 快速选择：近7天
        binding.chipPastWeek.setOnClickListener {
            val now = Calendar.getInstance()
            selectedEndDate = dateFormat.format(now.time)
            now.add(Calendar.DAY_OF_YEAR, -6)
            selectedStartDate = dateFormat.format(now.time)
            binding.tvStartDate.text = selectedStartDate
            binding.tvEndDate.text = selectedEndDate
        }

        // 快速选择：近30天 (推荐，更容易查到实际跑量)
        binding.chipPastMonth.setOnClickListener {
            val now = Calendar.getInstance()
            selectedEndDate = dateFormat.format(now.time)
            now.add(Calendar.DAY_OF_YEAR, -29)
            selectedStartDate = dateFormat.format(now.time)
            binding.tvStartDate.text = selectedStartDate
            binding.tvEndDate.text = selectedEndDate
        }

        // 拉取全部数据
        binding.btnFetchData.setOnClickListener {
            performDataFetch()
        }

        // 导出表格 (支持保存本地与第三方分享两种)
        binding.btnExportCsv.setOnClickListener {
            showExportOptionsDialog()
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                updateViewVisibility(tab?.position ?: 0)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun updateViewVisibility(tabIndex: Int) {
        when (tabIndex) {
            0 -> { // 健康总览
                binding.rvHealthTable.visibility = View.VISIBLE
                binding.layoutActivitiesContainer.visibility = View.GONE
            }
            1 -> { // 运动分段明细
                binding.rvHealthTable.visibility = View.GONE
                binding.layoutActivitiesContainer.visibility = View.VISIBLE
            }
        }
    }

    private fun showDatePicker(onSelected: (String) -> Unit) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val chosen = Calendar.getInstance()
                chosen.set(year, month, dayOfMonth)
                onSelected(dateFormat.format(chosen.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun performDataFetch() {
        val prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(LoginActivity.KEY_ACCESS_TOKEN, "")

        binding.progressBar.visibility = View.VISIBLE
        binding.btnFetchData.isEnabled = false

        lifecycleScope.launch {
            try {
                val client = CorosMcpClient(token)
                val result = client.fetchData(selectedStartDate, selectedEndDate)
                currentHealthData = result.healthRecords
                currentActivities = result.activities

                binding.progressBar.visibility = View.GONE
                binding.btnFetchData.isEnabled = true
                binding.btnExportCsv.isEnabled = true

                displayData(result.isRealData)

                // 弹出真实状态通知，让用户清晰获知数据来源
                Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                e.printStackTrace()
                binding.progressBar.visibility = View.GONE
                binding.btnFetchData.isEnabled = true
                Toast.makeText(this@MainActivity, "拉取提示: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun displayData(isRealData: Boolean) {
        try {
            // 1. 渲染健康表格
            binding.rvHealthTable.layoutManager = LinearLayoutManager(this)
            binding.rvHealthTable.adapter = HealthTableAdapter(currentHealthData)

            // 2. 渲染运动分段与配速心率列表
            val allLaps = currentActivities.flatMap { it.laps }
            binding.rvLapsTable.layoutManager = LinearLayoutManager(this)
            binding.rvLapsTable.adapter = LapDetailAdapter(allLaps)

            if (currentActivities.isNotEmpty()) {
                val firstAct = currentActivities[0]
                val prefix = if (isRealData) "🏃 [真实高驰数据] " else "🧪 [演示数据] "
                binding.tvActivitySummary.text = "$prefix${firstAct.sportName} | 距离: ${firstAct.distanceKm} km | 耗时: ${firstAct.durationMinutes} 分 | 平均配速: ${firstAct.avgPaceFormatted} | 平均心率: ${firstAct.avgHeartRate} bpm"
            } else {
                binding.tvActivitySummary.text = "✅ 已成功连通高驰：${selectedStartDate} 至 ${selectedEndDate} 期间暂无运动数据 (可尝试切换近30天)"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "数据展示异常: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 弹出两种导出选项：保存到本地下载目录 或 调用系统分享
     */
    private fun showExportOptionsDialog() {
        if (currentHealthData.isEmpty() && currentActivities.isEmpty()) {
            Toast.makeText(this, "暂无数据可导出，请先点击拉取数据", Toast.LENGTH_SHORT).show()
            return
        }

        val options = arrayOf(
            "📁 直接保存到手机【下载 (Download)】文件夹",
            "📤 分享到微信 / QQ / 其他应用"
        )

        MaterialAlertDialogBuilder(this)
            .setTitle("请选择表格导出方式")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> saveToLocalDownloads()
                    1 -> shareViaIntent()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun saveToLocalDownloads() {
        val fileName = "高驰运动健康数据_${selectedStartDate}_${selectedEndDate}.csv"
        val pathDesc = CsvExporter.saveToPublicDownloads(
            this,
            currentHealthData,
            currentActivities,
            fileName
        )

        if (pathDesc != null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("导出成功")
                .setMessage("表格已成功保存至 $pathDesc ！\n\n文件名：\n$fileName\n\n你可以打开手机自带的【文件管理】->【下载/Download】直接查看该表格。")
                .setPositiveButton("我知道了", null)
                .show()
        } else {
            Toast.makeText(this, "保存失败，请检查文件读写权限", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareViaIntent() {
        try {
            val csvFile = CsvExporter.exportToCsvFile(this, currentHealthData, currentActivities)
            val fileUri: Uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                csvFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "高驰运动与健康详细数据表导出")
                putExtra(Intent.EXTRA_STREAM, fileUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "分享或用表格查看数据"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "分享失败: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
