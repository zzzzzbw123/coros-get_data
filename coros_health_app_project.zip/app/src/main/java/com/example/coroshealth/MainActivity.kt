package com.example.coroshealth

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coroshealth.data.CorosMcpClient
import com.example.coroshealth.data.CsvExporter
import com.example.coroshealth.data.model.ActivityRecord
import com.example.coroshealth.data.model.DailyHealthRecord
import com.example.coroshealth.databinding.ActivityMainBinding
import com.example.coroshealth.ui.HealthTableAdapter
import com.example.coroshealth.ui.LapDetailAdapter
import com.example.coroshealth.ui.LoginActivity
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val calendar = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    private var selectedStartDate: String = ""
    private var selectedEndDate: String = ""

    private var currentHealthData: List<DailyHealthRecord> = emptyList()
    private var currentActivities: List<ActivityRecord> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initDefaultDates()
        setupListeners()
        setupTabs()
        checkAuthStatus()
    }

    override fun onResume() {
        super.onResume()
        checkAuthStatus()
    }

    private fun initDefaultDates() {
        val todayStr = dateFormat.format(calendar.time)
        selectedStartDate = todayStr
        selectedEndDate = todayStr
        binding.tvStartDate.text = selectedStartDate
        binding.tvEndDate.text = selectedEndDate
    }

    private fun checkAuthStatus() {
        val prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(LoginActivity.KEY_ACCESS_TOKEN, "")
        if (token.isNullOrBlank()) {
            binding.tvAuthStatus.text = "⚠️ 未连接高驰账号 (点击连接)"
            binding.tvAuthStatus.setTextColor(getColor(R.color.coros_orange))
        } else {
            binding.tvAuthStatus.text = "✅ 高驰 MCP 服务已授权绑定"
            binding.tvAuthStatus.setTextColor(getColor(R.color.coros_accent_green))
        }
    }

    private fun setupListeners() {
        // 跳转登录 / Token 配置
        binding.cardAuthStatus.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        // 选择开始日期
        binding.btnSelectStartDate.setOnClickListener {
            showDatePicker { dateStr ->
                selectedStartDate = dateStr
                binding.tvStartDate.text = dateStr
            }
        }

        // 选择结束日期
        binding.btnSelectEndDate.setOnClickListener {
            showDatePicker { dateStr ->
                selectedEndDate = dateStr
                binding.tvEndDate.text = dateStr
            }
        }

        // 快速选择：今天
        binding.chipToday.setOnClickListener {
            val todayStr = dateFormat.format(Calendar.getInstance().time)
            selectedStartDate = todayStr
            selectedEndDate = todayStr
            binding.tvStartDate.text = todayStr
            binding.tvEndDate.text = todayStr
        }

        // 快速选择：近7天
        binding.chipPastWeek.setOnClickListener {
            val now = Calendar.getInstance()
            selectedEndDate = dateFormat.format(now.time)
            now.add(Calendar.DAY_OF_YEAR, -6)
            selectedStartDate = dateFormat.format(now.time)
            binding.tvStartDate.text = selectedStartDate
            binding.tvEndDate.text = selectedEndDate
        }

        // 拉取全部数据
        binding.btnFetchData.setOnClickListener {
            performDataFetch()
        }

        // 导出 CSV 表格
        binding.btnExportCsv.setOnClickListener {
            exportAndShareCsv()
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                updateViewVisibility(tab?.position ?: 0)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun updateViewVisibility(tabIndex: Int) {
        when (tabIndex) {
            0 -> { // 健康总览
                binding.rvHealthTable.visibility = View.VISIBLE
                binding.layoutActivitiesContainer.visibility = View.GONE
            }
            1 -> { // 运动分段明细
                binding.rvHealthTable.visibility = View.GONE
                binding.layoutActivitiesContainer.visibility = View.VISIBLE
            }
        }
    }

    private fun showDatePicker(onSelected: (String) -> Unit) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val chosen = Calendar.getInstance()
                chosen.set(year, month, dayOfMonth)
                onSelected(dateFormat.format(chosen.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun performDataFetch() {
        val prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(LoginActivity.KEY_ACCESS_TOKEN, "")

        binding.progressBar.visibility = View.VISIBLE
        binding.btnFetchData.isEnabled = false

        lifecycleScope.launch {
            val client = CorosMcpClient(token)
            val result = client.fetchData(selectedStartDate, selectedEndDate)
            currentHealthData = result.first
            currentActivities = result.second

            binding.progressBar.visibility = View.GONE
            binding.btnFetchData.isEnabled = true
            binding.btnExportCsv.isEnabled = true

            displayData()
            Toast.makeText(this@MainActivity, "成功获取 ${selectedStartDate} 至 ${selectedEndDate} 的全部健康与分段数据！", Toast.LENGTH_SHORT).show()
        }
    }

    private fun displayData() {
        // 1. 渲染健康表格
        binding.rvHealthTable.layoutManager = LinearLayoutManager(this)
        binding.rvHealthTable.adapter = HealthTableAdapter(currentHealthData)

        // 2. 渲染运动分段与配速心率列表
        val allLaps = currentActivities.flatMap { it.laps }
        binding.rvLapsTable.layoutManager = LinearLayoutManager(this)
        binding.rvLapsTable.adapter = LapDetailAdapter(allLaps)

        if (currentActivities.isNotEmpty()) {
            val firstAct = currentActivities[0]
            binding.tvActivitySummary.text = "🏃 ${firstAct.sportName} | 距离: ${firstAct.distanceKm} km | 耗时: ${firstAct.durationMinutes} 分 | 平均配速: ${firstAct.avgPaceFormatted} | 平均心率: ${firstAct.avgHeartRate} bpm"
        }
    }

    private fun exportAndShareCsv() {
        if (currentHealthData.isEmpty() && currentActivities.isEmpty()) {
            Toast.makeText(this, "暂无数据可导出，请先点击拉取数据", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val csvFile = CsvExporter.exportToCsvFile(this, currentHealthData, currentActivities)
            val fileUri: Uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                csvFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "高驰运动与健康详细数据表导出")
                putExtra(Intent.EXTRA_STREAM, fileUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "分享或用表格查看数据"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "导出失败: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
