# Keep models for Gson serialization
-keep class com.example.coroshealth.data.model.** { *; }
